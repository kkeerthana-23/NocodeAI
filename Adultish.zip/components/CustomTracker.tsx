import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Plus, Target, Calendar, TrendingUp, Settings, BarChart3, Hash, CheckCircle, Clock } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";

interface CustomTracker {
  id: string;
  name: string;
  description: string;
  type: 'numeric' | 'boolean' | 'rating' | 'text';
  unit?: string; // for numeric types
  goal?: number; // target value
  color: string;
  icon: string;
  createdDate: string;
  entries: TrackerEntry[];
}

interface TrackerEntry {
  id: string;
  value: string | number | boolean;
  date: string;
  notes?: string;
}

const trackerColors = [
  'bg-blue-500', 'bg-green-500', 'bg-purple-500', 'bg-orange-500', 
  'bg-pink-500', 'bg-teal-500', 'bg-red-500', 'bg-indigo-500'
];

const trackerIcons = [
  '📊', '🎯', '💪', '📚', '🎨', '💰', '🏃', '🧘', '☕', '🌱'
];

export function CustomTracker() {
  const [trackers, setTrackers] = useState<CustomTracker[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTracker, setSelectedTracker] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const [newTracker, setNewTracker] = useState({
    name: '',
    description: '',
    type: 'numeric' as CustomTracker['type'],
    unit: '',
    goal: '',
    color: trackerColors[0],
    icon: trackerIcons[0]
  });

  const [newEntry, setNewEntry] = useState({
    value: '',
    notes: ''
  });

  useEffect(() => {
    loadTrackers();
  }, []);

  const loadTrackers = async () => {
    setLoading(true);
    // Simulate API call - replace with actual API call
    setTimeout(() => {
      const sampleTrackers: CustomTracker[] = [
        {
          id: '1',
          name: 'Water Intake',
          description: 'Daily water consumption',
          type: 'numeric',
          unit: 'glasses',
          goal: 8,
          color: 'bg-blue-500',
          icon: '💧',
          createdDate: '2024-01-10',
          entries: [
            { id: '1', value: 6, date: '2024-01-15', notes: 'Forgot to drink during lunch' },
            { id: '2', value: 8, date: '2024-01-14', notes: 'Great day!' },
            { id: '3', value: 7, date: '2024-01-13' }
          ]
        },
        {
          id: '2',
          name: 'Gratitude Practice',
          description: 'Daily gratitude reflection',
          type: 'boolean',
          color: 'bg-green-500',
          icon: '🙏',
          createdDate: '2024-01-08',
          entries: [
            { id: '4', value: true, date: '2024-01-15', notes: 'Grateful for family time' },
            { id: '5', value: true, date: '2024-01-14' },
            { id: '6', value: false, date: '2024-01-13' }
          ]
        },
        {
          id: '3',
          name: 'Code Quality',
          description: 'Daily code quality self-assessment',
          type: 'rating',
          goal: 4,
          color: 'bg-purple-500',
          icon: '💻',
          createdDate: '2024-01-05',
          entries: [
            { id: '7', value: 4, date: '2024-01-15', notes: 'Clean refactoring today' },
            { id: '8', value: 3, date: '2024-01-14' },
            { id: '9', value: 5, date: '2024-01-13', notes: 'Excellent code review' }
          ]
        }
      ];
      setTrackers(sampleTrackers);
      setLoading(false);
    }, 1000);
  };

  const addTracker = () => {
    if (!newTracker.name) return;

    const tracker: CustomTracker = {
      id: Date.now().toString(),
      name: newTracker.name,
      description: newTracker.description,
      type: newTracker.type,
      unit: newTracker.unit || undefined,
      goal: newTracker.goal ? parseFloat(newTracker.goal) : undefined,
      color: newTracker.color,
      icon: newTracker.icon,
      createdDate: new Date().toISOString().split('T')[0],
      entries: []
    };

    setTrackers([...trackers, tracker]);
    setNewTracker({
      name: '',
      description: '',
      type: 'numeric',
      unit: '',
      goal: '',
      color: trackerColors[0],
      icon: trackerIcons[0]
    });
    toast.success('Custom tracker created successfully!');
    setDialogOpen(false);
  };

  const addEntry = (trackerId: string) => {
    if (!newEntry.value && newEntry.value !== false) return;

    const tracker = trackers.find(t => t.id === trackerId);
    if (!tracker) return;

    let processedValue: string | number | boolean = newEntry.value;
    
    if (tracker.type === 'numeric' || tracker.type === 'rating') {
      processedValue = parseFloat(newEntry.value as string);
    } else if (tracker.type === 'boolean') {
      processedValue = newEntry.value === 'true';
    }

    const entry: TrackerEntry = {
      id: Date.now().toString(),
      value: processedValue,
      date: new Date().toISOString().split('T')[0],
      notes: newEntry.notes || undefined
    };

    setTrackers(trackers.map(t => 
      t.id === trackerId 
        ? { ...t, entries: [entry, ...t.entries] }
        : t
    ));

    setNewEntry({ value: '', notes: '' });
    setSelectedTracker(null);
    toast.success('Entry logged successfully!');
  };

  const getTrackerProgress = (tracker: CustomTracker) => {
    if (!tracker.goal || tracker.entries.length === 0) return 0;
    
    const latestEntry = tracker.entries[0];
    if (tracker.type === 'boolean') {
      return latestEntry.value ? 100 : 0;
    } else if (tracker.type === 'numeric' || tracker.type === 'rating') {
      return Math.min((latestEntry.value as number / tracker.goal) * 100, 100);
    }
    return 0;
  };

  const getTrackerStreak = (tracker: CustomTracker) => {
    const today = new Date();
    let streak = 0;
    
    for (let i = 0; i < 30; i++) {
      const checkDate = new Date(today);
      checkDate.setDate(today.getDate() - i);
      const dateStr = checkDate.toISOString().split('T')[0];
      
      const entry = tracker.entries.find(e => e.date === dateStr);
      
      if (entry) {
        if (tracker.type === 'boolean' && entry.value) {
          streak++;
        } else if ((tracker.type === 'numeric' || tracker.type === 'rating') && entry.value) {
          streak++;
        } else if (tracker.type === 'text' && entry.value) {
          streak++;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    
    return streak;
  };

  const formatValue = (tracker: CustomTracker, value: string | number | boolean) => {
    if (tracker.type === 'boolean') {
      return value ? '✅ Yes' : '❌ No';
    } else if (tracker.type === 'rating') {
      return `${value}/5 ⭐`;
    } else if (tracker.type === 'numeric') {
      return `${value}${tracker.unit ? ' ' + tracker.unit : ''}`;
    }
    return value.toString();
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-semibold">Custom Trackers</h1>
            <p className="text-muted-foreground">Loading your trackers...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold">Custom Trackers</h1>
          <p className="text-muted-foreground">Create and track your own metrics</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              New Tracker
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create Custom Tracker</DialogTitle>
              <DialogDescription>
                Define a new metric that you want to track over time.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="tracker-name">Tracker Name</Label>
                <Input
                  id="tracker-name"
                  value={newTracker.name}
                  onChange={(e) => setNewTracker({...newTracker, name: e.target.value})}
                  placeholder="e.g., Daily Steps, Reading Time, Meditation"
                />
              </div>
              
              <div>
                <Label htmlFor="tracker-description">Description</Label>
                <Textarea
                  id="tracker-description"
                  value={newTracker.description}
                  onChange={(e) => setNewTracker({...newTracker, description: e.target.value})}
                  placeholder="What are you tracking and why?"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="tracker-type">Data Type</Label>
                  <Select value={newTracker.type} onValueChange={(value: CustomTracker['type']) => setNewTracker({...newTracker, type: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="numeric">Number (e.g., 5, 10.5)</SelectItem>
                      <SelectItem value="boolean">Yes/No</SelectItem>
                      <SelectItem value="rating">Rating 1-5</SelectItem>
                      <SelectItem value="text">Text Note</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {newTracker.type === 'numeric' && (
                  <div>
                    <Label htmlFor="tracker-unit">Unit (optional)</Label>
                    <Input
                      id="tracker-unit"
                      value={newTracker.unit}
                      onChange={(e) => setNewTracker({...newTracker, unit: e.target.value})}
                      placeholder="e.g., steps, minutes, cups"
                    />
                  </div>
                )}
              </div>

              {(newTracker.type === 'numeric' || newTracker.type === 'rating') && (
                <div>
                  <Label htmlFor="tracker-goal">Daily Goal (optional)</Label>
                  <Input
                    id="tracker-goal"
                    type="number"
                    value={newTracker.goal}
                    onChange={(e) => setNewTracker({...newTracker, goal: e.target.value})}
                    placeholder="Target value to achieve each day"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Color</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {trackerColors.map(color => (
                      <button
                        key={color}
                        className={`w-8 h-8 rounded-full ${color} ${newTracker.color === color ? 'ring-2 ring-offset-2 ring-primary' : ''}`}
                        onClick={() => setNewTracker({...newTracker, color})}
                      />
                    ))}
                  </div>
                </div>

                <div>
                  <Label>Icon</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {trackerIcons.map(icon => (
                      <button
                        key={icon}
                        className={`w-8 h-8 text-lg border rounded ${newTracker.icon === icon ? 'border-primary bg-primary/10' : 'border-gray-300'}`}
                        onClick={() => setNewTracker({...newTracker, icon})}
                      >
                        {icon}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <Button onClick={addTracker} className="w-full">
                Create Tracker
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tracker Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Trackers</CardTitle>
            <Hash className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{trackers.length}</div>
            <p className="text-xs text-muted-foreground">active trackers</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Logged Today</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {trackers.filter(t => t.entries.some(e => e.date === new Date().toISOString().split('T')[0])).length}
            </div>
            <p className="text-xs text-muted-foreground">entries today</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Streak</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {trackers.length > 0 ? Math.round(trackers.reduce((sum, t) => sum + getTrackerStreak(t), 0) / trackers.length) : 0}
            </div>
            <p className="text-xs text-muted-foreground">days average</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Entries</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {trackers.reduce((sum, t) => sum + t.entries.length, 0)}
            </div>
            <p className="text-xs text-muted-foreground">all time</p>
          </CardContent>
        </Card>
      </div>

      {/* Trackers Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {trackers.length === 0 ? (
          <div className="col-span-full">
            <Card>
              <CardContent className="p-8 text-center">
                <Target className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No custom trackers yet</h3>
                <p className="text-muted-foreground mb-4">Create your first custom tracker to start monitoring what matters to you!</p>
                <Button onClick={() => setDialogOpen(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Your First Tracker
                </Button>
              </CardContent>
            </Card>
          </div>
        ) : (
          trackers.map((tracker) => (
            <Card key={tracker.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 ${tracker.color} rounded-lg flex items-center justify-center text-white text-lg`}>
                      {tracker.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold">{tracker.name}</h3>
                      <p className="text-sm text-muted-foreground">{tracker.description}</p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {tracker.type}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {tracker.goal && (
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium">Progress</span>
                        <span className="text-sm text-muted-foreground">{getTrackerProgress(tracker).toFixed(0)}%</span>
                      </div>
                      <Progress value={getTrackerProgress(tracker)} className="h-2" />
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Streak:</span>
                      <span className="ml-1 font-medium">{getTrackerStreak(tracker)} days</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Entries:</span>
                      <span className="ml-1 font-medium">{tracker.entries.length}</span>
                    </div>
                  </div>

                  {tracker.entries.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2">Recent Entries</h4>
                      <div className="space-y-2 max-h-32 overflow-y-auto">
                        {tracker.entries.slice(0, 3).map((entry) => (
                          <div key={entry.id} className="flex justify-between items-center text-sm p-2 rounded border">
                            <span>{formatValue(tracker, entry.value)}</span>
                            <span className="text-muted-foreground">{entry.date}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex gap-2 pt-2">
                    <Dialog open={selectedTracker === tracker.id} onOpenChange={(open) => setSelectedTracker(open ? tracker.id : null)}>
                      <DialogTrigger asChild>
                        <Button size="sm" className="flex-1">
                          <Plus className="w-3 h-3 mr-1" />
                          Log Entry
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Log Entry for {tracker.name}</DialogTitle>
                          <DialogDescription>
                            Add a new data point for tracking.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="entry-value">Value</Label>
                            {tracker.type === 'boolean' ? (
                              <Select value={newEntry.value as string} onValueChange={(value) => setNewEntry({...newEntry, value})}>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select..." />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="true">Yes</SelectItem>
                                  <SelectItem value="false">No</SelectItem>
                                </SelectContent>
                              </Select>
                            ) : tracker.type === 'rating' ? (
                              <Select value={newEntry.value as string} onValueChange={(value) => setNewEntry({...newEntry, value})}>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select rating..." />
                                </SelectTrigger>
                                <SelectContent>
                                  {[1, 2, 3, 4, 5].map(rating => (
                                    <SelectItem key={rating} value={rating.toString()}>
                                      {rating} ⭐
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            ) : tracker.type === 'numeric' ? (
                              <Input
                                type="number"
                                step="0.1"
                                value={newEntry.value}
                                onChange={(e) => setNewEntry({...newEntry, value: e.target.value})}
                                placeholder={`Enter ${tracker.unit || 'value'}`}
                              />
                            ) : (
                              <Textarea
                                value={newEntry.value as string}
                                onChange={(e) => setNewEntry({...newEntry, value: e.target.value})}
                                placeholder="Enter your note..."
                              />
                            )}
                          </div>
                          
                          <div>
                            <Label htmlFor="entry-notes">Notes (optional)</Label>
                            <Input
                              id="entry-notes"
                              value={newEntry.notes}
                              onChange={(e) => setNewEntry({...newEntry, notes: e.target.value})}
                              placeholder="Any additional notes..."
                            />
                          </div>

                          <Button onClick={() => addEntry(tracker.id)} className="w-full">
                            Log Entry
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                    
                    <Button variant="outline" size="sm">
                      <Settings className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}