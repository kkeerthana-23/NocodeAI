import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Smile, Plus, TrendingUp, Heart, Calendar, Edit, Trash2, Save, X } from "lucide-react";
import { useState, useEffect } from "react";
import { moodApi } from "../utils/api";
import { toast } from "sonner";

interface MoodEntry {
  id: string;
  mood: string;
  energy: number;
  stress: number;
  notes: string;
  tags: string[];
  date: string;
}

const moodOptions = [
  { value: 'very-happy', label: 'Very Happy', icon: '😄', color: 'text-green-600' },
  { value: 'happy', label: 'Happy', icon: '😊', color: 'text-green-500' },
  { value: 'neutral', label: 'Neutral', icon: '😐', color: 'text-yellow-500' },
  { value: 'sad', label: 'Sad', icon: '😔', color: 'text-orange-500' },
  { value: 'very-sad', label: 'Very Sad', icon: '😢', color: 'text-red-500' },
];

const commonTags = ['work', 'family', 'friends', 'exercise', 'sleep', 'weather', 'health', 'achievement', 'stress', 'relaxation'];

export function MoodTracker() {
  const [moods, setMoods] = useState<MoodEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingMood, setEditingMood] = useState<string | null>(null);

  useEffect(() => {
    loadMoods();
  }, []);

  const loadMoods = async () => {
    setLoading(true);
    const { data, error } = await moodApi.getMoodEntries();
    
    if (error) {
      toast.error('Failed to load mood entries: ' + error);
    } else if (data) {
      setMoods(data.moods);
    }
    
    setLoading(false);
  };

  const [newMood, setNewMood] = useState({
    mood: 'happy',
    energy: 3,
    stress: 2,
    notes: '',
    tags: [] as string[]
  });

  const [editMood, setEditMood] = useState({
    mood: 'happy',
    energy: 3,
    stress: 2,
    notes: '',
    tags: [] as string[]
  });

  const addMoodEntry = async () => {
    const { data, error } = await moodApi.createMoodEntry(newMood);
    
    if (error) {
      toast.error('Failed to create mood entry: ' + error);
    } else if (data) {
      setMoods([data.mood, ...moods]);
      setNewMood({ mood: 'happy', energy: 3, stress: 2, notes: '', tags: [] });
      setDialogOpen(false);
      toast.success('Mood entry created successfully!');
    }
  };

  const startEditMood = (mood: MoodEntry) => {
    setEditMood({
      mood: mood.mood,
      energy: mood.energy,
      stress: mood.stress,
      notes: mood.notes,
      tags: mood.tags || []
    });
    setEditingMood(mood.id);
  };

  const saveMoodEdit = async (moodId: string) => {
    const { data, error } = await moodApi.updateMoodEntry(moodId, editMood);

    if (error) {
      toast.error('Failed to update mood entry: ' + error);
    } else if (data) {
      setMoods(moods.map(m => m.id === moodId ? data.mood : m));
      setEditingMood(null);
      toast.success('Mood entry updated successfully!');
    }
  };

  const cancelMoodEdit = () => {
    setEditingMood(null);
    setEditMood({ mood: 'happy', energy: 3, stress: 2, notes: '', tags: [] });
  };

  const deleteMoodEntry = async (moodId: string) => {
    if (!confirm('Are you sure you want to delete this mood entry?')) return;

    const { error } = await moodApi.deleteMoodEntry(moodId);
    
    if (error) {
      toast.error('Failed to delete mood entry: ' + error);
    } else {
      setMoods(moods.filter(m => m.id !== moodId));
      toast.success('Mood entry deleted successfully!');
    }
  };

  const toggleTag = (tag: string, isEditMode = false) => {
    const currentMood = isEditMode ? editMood : newMood;
    const setter = isEditMode ? setEditMood : setNewMood;
    
    const newTags = currentMood.tags.includes(tag)
      ? currentMood.tags.filter(t => t !== tag)
      : [...currentMood.tags, tag];
    
    setter({ ...currentMood, tags: newTags });
  };

  const getMoodIcon = (moodValue: string) => {
    return moodOptions.find(m => m.value === moodValue)?.icon || '😊';
  };

  const getMoodLabel = (moodValue: string) => {
    return moodOptions.find(m => m.value === moodValue)?.label || 'Happy';
  };

  const averageEnergy = moods.length > 0 ? Math.round(moods.reduce((sum, m) => sum + m.energy, 0) / moods.length) : 0;
  const averageStress = moods.length > 0 ? Math.round(moods.reduce((sum, m) => sum + m.stress, 0) / moods.length) : 0;
  const todaysMood = moods.find(m => {
    const today = new Date().toDateString();
    const moodDate = new Date(m.date).toDateString();
    return today === moodDate;
  });

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-semibold">Mood Tracker</h1>
            <p className="text-muted-foreground">Loading your mood entries...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold">Mood Tracker</h1>
          <p className="text-muted-foreground">Track your daily mood, energy, and stress levels</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Log Mood
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Log Your Mood</DialogTitle>
              <DialogDescription>
                Record how you're feeling today with optional notes and tags.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Mood</Label>
                <div className="grid grid-cols-5 gap-2 mt-2">
                  {moodOptions.map((option) => (
                    <Button
                      key={option.value}
                      variant={newMood.mood === option.value ? "default" : "outline"}
                      className="flex flex-col h-20 p-2"
                      onClick={() => setNewMood({...newMood, mood: option.value})}
                    >
                      <span className="text-2xl mb-1">{option.icon}</span>
                      <span className="text-xs">{option.label}</span>
                    </Button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="energy">Energy Level: {newMood.energy}/5</Label>
                  <Input
                    id="energy"
                    type="range"
                    min="1"
                    max="5"
                    value={newMood.energy}
                    onChange={(e) => setNewMood({...newMood, energy: parseInt(e.target.value)})}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="stress">Stress Level: {newMood.stress}/5</Label>
                  <Input
                    id="stress"
                    type="range"
                    min="1"
                    max="5"
                    value={newMood.stress}
                    onChange={(e) => setNewMood({...newMood, stress: parseInt(e.target.value)})}
                    className="mt-2"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="notes">Notes (optional)</Label>
                <Textarea
                  id="notes"
                  value={newMood.notes}
                  onChange={(e) => setNewMood({...newMood, notes: e.target.value})}
                  placeholder="What's influencing your mood today?"
                  className="mt-2"
                />
              </div>

              <div>
                <Label>Tags (optional)</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {commonTags.map((tag) => (
                    <Badge
                      key={tag}
                      variant={newMood.tags.includes(tag) ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => toggleTag(tag)}
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>

              <Button onClick={addMoodEntry} className="w-full">
                Log Mood
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Mood Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Mood</CardTitle>
            <Smile className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {todaysMood ? (
              <div className="flex items-center gap-2">
                <span className="text-2xl">{getMoodIcon(todaysMood.mood)}</span>
                <div>
                  <div className="text-lg font-semibold">{getMoodLabel(todaysMood.mood)}</div>
                  <p className="text-xs text-muted-foreground">Energy: {todaysMood.energy}/5</p>
                </div>
              </div>
            ) : (
              <div className="text-sm text-muted-foreground">No entry yet today</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Energy</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageEnergy}/5</div>
            <p className="text-xs text-muted-foreground">past 30 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Stress</CardTitle>
            <Heart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageStress}/5</div>
            <p className="text-xs text-muted-foreground">past 30 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Entries</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{moods.length}</div>
            <p className="text-xs text-muted-foreground">mood logs</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Mood Entries */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smile className="h-5 w-5" />
            Recent Mood Entries
          </CardTitle>
        </CardHeader>
        <CardContent>
          {moods.length === 0 ? (
            <div className="p-8 text-center">
              <Smile className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No mood entries yet</h3>
              <p className="text-muted-foreground mb-4">Start tracking your mood to better understand your emotional patterns!</p>
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Log Your First Mood
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {moods.slice(0, 10).map((mood) => (
                <div key={mood.id} className="flex items-center justify-between p-4 rounded-lg border">
                  {editingMood === mood.id ? (
                    <div className="flex-1 space-y-4 mr-4">
                      <div className="grid grid-cols-5 gap-2">
                        {moodOptions.map((option) => (
                          <Button
                            key={option.value}
                            variant={editMood.mood === option.value ? "default" : "outline"}
                            className="flex flex-col h-16 p-1"
                            onClick={() => setEditMood({...editMood, mood: option.value})}
                          >
                            <span className="text-lg">{option.icon}</span>
                            <span className="text-xs">{option.label}</span>
                          </Button>
                        ))}
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Energy: {editMood.energy}/5</Label>
                          <Input
                            type="range"
                            min="1"
                            max="5"
                            value={editMood.energy}
                            onChange={(e) => setEditMood({...editMood, energy: parseInt(e.target.value)})}
                          />
                        </div>
                        <div>
                          <Label>Stress: {editMood.stress}/5</Label>
                          <Input
                            type="range"
                            min="1"
                            max="5"
                            value={editMood.stress}
                            onChange={(e) => setEditMood({...editMood, stress: parseInt(e.target.value)})}
                          />
                        </div>
                      </div>
                      <Textarea
                        value={editMood.notes}
                        onChange={(e) => setEditMood({...editMood, notes: e.target.value})}
                        placeholder="Notes..."
                      />
                      <div className="flex flex-wrap gap-2">
                        {commonTags.map((tag) => (
                          <Badge
                            key={tag}
                            variant={editMood.tags.includes(tag) ? "default" : "outline"}
                            className="cursor-pointer"
                            onClick={() => toggleTag(tag, true)}
                          >
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-4 flex-1">
                      <span className="text-3xl">{getMoodIcon(mood.mood)}</span>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-medium">{getMoodLabel(mood.mood)}</h3>
                          <span className="text-sm text-muted-foreground">{mood.date}</span>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                          <span>Energy: {mood.energy}/5</span>
                          <span>Stress: {mood.stress}/5</span>
                        </div>
                        {mood.notes && (
                          <p className="text-sm text-muted-foreground mb-2">{mood.notes}</p>
                        )}
                        {mood.tags && mood.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {mood.tags.map((tag, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    {editingMood === mood.id ? (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => saveMoodEdit(mood.id)}
                          className="text-green-600 hover:text-green-700"
                        >
                          <Save className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={cancelMoodEdit}
                          className="text-gray-600 hover:text-gray-700"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => startEditMood(mood)}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteMoodEntry(mood.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}