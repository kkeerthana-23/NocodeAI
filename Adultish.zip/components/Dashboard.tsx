import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Calendar, CheckCircle, Flame, TrendingUp, Users, Zap, Smile, Heart } from "lucide-react";
import { Button } from "./ui/button";

export function Dashboard() {
  const todayHabits = [
    { name: "Morning Meditation", completed: true },
    { name: "Drink 8 glasses of water", completed: false },
    { name: "Read for 30 minutes", completed: true },
    { name: "Exercise", completed: false },
  ];

  const upcomingGoals = [
    { name: "Complete React Course", deadline: "Dec 31", progress: 75 },
    { name: "Run 5K", deadline: "Jan 15", progress: 40 },
    { name: "Learn Spanish", deadline: "Mar 30", progress: 20 },
  ];

  const recentProjects = [
    { name: "Personal Blog", status: "In Progress", lastWorked: "2 days ago" },
    { name: "Photography Portfolio", status: "Planning", lastWorked: "1 week ago" },
    { name: "Mobile App Idea", status: "Brainstorming", lastWorked: "3 days ago" },
  ];

  const completedHabits = todayHabits.filter(h => h.completed).length;
  const habitCompletionRate = Math.round((completedHabits / todayHabits.length) * 100);

  // Mock mood data - replace with actual data from mood tracker
  const todayMood = {
    mood: 'happy',
    icon: '😊',
    energy: 4,
    stress: 2
  };

  const recentMoods = [
    { date: 'Today', mood: 'happy', icon: '😊' },
    { date: 'Yesterday', mood: 'neutral', icon: '😐' },
    { date: '2 days ago', mood: 'very-happy', icon: '😄' },
    { date: '3 days ago', mood: 'happy', icon: '😊' },
  ];

  return (
    <div className="space-y-8">
      <div className="bg-card border rounded-lg p-8">
        <h1 className="text-3xl font-semibold mb-2 text-card-foreground">Good morning, John! 👋</h1>
        <p className="text-muted-foreground">Here's your life overview for today</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Habits</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedHabits}/{todayHabits.length}</div>
            <div className="flex items-center gap-2 mt-2">
              <Progress value={habitCompletionRate} className="flex-1" />
              <span className="text-sm text-muted-foreground">{habitCompletionRate}%</span>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Streak</CardTitle>
            <Flame className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">15</div>
            <p className="text-xs text-muted-foreground">days strong</p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Goals</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{upcomingGoals.length}</div>
            <p className="text-xs text-muted-foreground">in progress</p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Mood</CardTitle>
            <Heart className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <span className="text-2xl">{todayMood.icon}</span>
              <div>
                <div className="text-lg font-semibold capitalize">{todayMood.mood}</div>
                <p className="text-xs text-muted-foreground">Energy: {todayMood.energy}/5</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Today's Habits */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5" />
            Today's Habits
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {todayHabits.map((habit, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg hover:bg-secondary/70 transition-colors">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${habit.completed ? 'bg-green-500' : 'bg-muted'}`} />
                  <span className={habit.completed ? 'line-through text-muted-foreground' : 'text-card-foreground'}>{habit.name}</span>
                </div>
                <Button variant="ghost" size="sm" onClick={() => console.log('Toggle habit:', habit.name)}>
                  {habit.completed ? 'Completed' : 'Mark Done'}
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Mood Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smile className="h-5 w-5" />
            Mood This Week
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              {recentMoods.map((mood, index) => (
                <div key={index} className="text-center bg-secondary p-3 rounded-lg">
                  <div className="text-2xl mb-1">{mood.icon}</div>
                  <p className="text-xs text-muted-foreground">{mood.date}</p>
                </div>
              ))}
            </div>
            <div className="text-right bg-secondary p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-sm text-muted-foreground">Energy:</span>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((level) => (
                    <div
                      key={level}
                      className={`w-2 h-2 rounded-full ${
                        level <= todayMood.energy ? 'bg-green-500' : 'bg-muted'
                      }`}
                    />
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Stress:</span>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((level) => (
                    <div
                      key={level}
                      className={`w-2 h-2 rounded-full ${
                        level <= todayMood.stress ? 'bg-red-500' : 'bg-muted'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Goals & Projects */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Active Goals
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingGoals.map((goal, index) => (
                <div key={index} className="space-y-2 p-3 bg-secondary/50 rounded-lg">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{goal.name}</span>
                    <Badge variant="outline">{goal.deadline}</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Progress value={goal.progress} className="flex-1" />
                    <span className="text-sm text-muted-foreground">{goal.progress}%</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Recent Projects
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentProjects.map((project, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-secondary/50 rounded-lg hover:bg-secondary/70 transition-colors">
                  <div>
                    <p className="font-medium">{project.name}</p>
                    <p className="text-sm text-muted-foreground">Last worked: {project.lastWorked}</p>
                  </div>
                  <Badge variant="secondary">{project.status}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}