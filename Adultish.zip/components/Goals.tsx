import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Target, Plus, TrendingUp, Calendar, CheckCircle, Edit, Trash2, Save, X, Flag } from "lucide-react";
import { useState, useEffect } from "react";
import { goalsApi } from "../utils/api";
import { toast } from "sonner";

interface Goal {
  id: string;
  title: string;
  description: string;
  category: string;
  priority: string;
  targetDate: string;
  progress: number;
  status: string;
  createdAt: string;
}

export function Goals() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<string | null>(null);

  useEffect(() => {
    loadGoals();
  }, []);

  const loadGoals = async () => {
    setLoading(true);
    const { data, error } = await goalsApi.getGoals();
    
    if (error) {
      toast.error('Failed to load goals: ' + error);
    } else if (data) {
      setGoals(data.goals);
    }
    
    setLoading(false);
  };

  const [newGoal, setNewGoal] = useState({
    title: '',
    description: '',
    category: 'Personal',
    priority: 'Medium',
    targetDate: '',
    progress: 0
  });

  const [editGoal, setEditGoal] = useState({
    title: '',
    description: '',
    category: 'Personal',
    priority: 'Medium',
    targetDate: '',
    progress: 0
  });

  const categories = ['Personal', 'Career', 'Health', 'Financial', 'Education', 'Relationships', 'Other'];
  const priorities = ['Low', 'Medium', 'High', 'Critical'];
  const statuses = ['Not Started', 'In Progress', 'Completed', 'On Hold'];

  const addGoal = async () => {
    if (!newGoal.title.trim()) {
      toast.error('Please enter a goal title');
      return;
    }

    const goalData = {
      ...newGoal,
      status: 'Not Started'
    };

    const { data, error } = await goalsApi.createGoal(goalData);
    
    if (error) {
      toast.error('Failed to create goal: ' + error);
    } else if (data) {
      setGoals([data.goal, ...goals]);
      setNewGoal({ title: '', description: '', category: 'Personal', priority: 'Medium', targetDate: '', progress: 0 });
      setDialogOpen(false);
      toast.success('Goal created successfully!');
    }
  };

  const startEditGoal = (goal: Goal) => {
    setEditGoal({
      title: goal.title,
      description: goal.description,
      category: goal.category,
      priority: goal.priority,
      targetDate: goal.targetDate,
      progress: goal.progress
    });
    setEditingGoal(goal.id);
  };

  const saveGoalEdit = async (goalId: string) => {
    if (!editGoal.title.trim()) {
      toast.error('Please enter a goal title');
      return;
    }

    const { data, error } = await goalsApi.updateGoal(goalId, editGoal);

    if (error) {
      toast.error('Failed to update goal: ' + error);
    } else if (data) {
      setGoals(goals.map(g => g.id === goalId ? data.goal : g));
      setEditingGoal(null);
      toast.success('Goal updated successfully!');
    }
  };

  const cancelGoalEdit = () => {
    setEditingGoal(null);
    setEditGoal({ title: '', description: '', category: 'Personal', priority: 'Medium', targetDate: '', progress: 0 });
  };

  const deleteGoal = async (goalId: string) => {
    if (!confirm('Are you sure you want to delete this goal?')) return;

    const { error } = await goalsApi.deleteGoal(goalId);
    
    if (error) {
      toast.error('Failed to delete goal: ' + error);
    } else {
      setGoals(goals.filter(g => g.id !== goalId));
      toast.success('Goal deleted successfully!');
    }
  };

  const updateProgress = async (goalId: string, newProgress: number) => {
    const updates = {
      progress: newProgress,
      status: newProgress === 100 ? 'Completed' : newProgress > 0 ? 'In Progress' : 'Not Started'
    };

    const { data, error } = await goalsApi.updateGoal(goalId, updates);

    if (error) {
      toast.error('Failed to update progress: ' + error);
    } else if (data) {
      setGoals(goals.map(g => g.id === goalId ? data.goal : g));
      toast.success('Progress updated!');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed': return 'bg-green-100 text-green-800';
      case 'In Progress': return 'bg-blue-100 text-blue-800';
      case 'On Hold': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Critical': return 'bg-red-100 text-red-800';
      case 'High': return 'bg-orange-100 text-orange-800';
      case 'Medium': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const completedGoals = goals.filter(g => g.status === 'Completed').length;
  const inProgressGoals = goals.filter(g => g.status === 'In Progress').length;
  const averageProgress = goals.length > 0 ? Math.round(goals.reduce((sum, g) => sum + g.progress, 0) / goals.length) : 0;

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-semibold">Goals</h1>
            <p className="text-muted-foreground">Loading your goals...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold">Goals</h1>
          <p className="text-muted-foreground">Set and track your life goals</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Goal
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Goal</DialogTitle>
              <DialogDescription>
                Set a new goal with details about what you want to achieve and when.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="goal-title">Goal Title</Label>
                <Input
                  id="goal-title"
                  value={newGoal.title}
                  onChange={(e) => setNewGoal({...newGoal, title: e.target.value})}
                  placeholder="e.g., Learn Spanish fluently"
                />
              </div>
              <div>
                <Label htmlFor="goal-description">Description</Label>
                <Textarea
                  id="goal-description"
                  value={newGoal.description}
                  onChange={(e) => setNewGoal({...newGoal, description: e.target.value})}
                  placeholder="Describe your goal in detail..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="goal-category">Category</Label>
                  <Select value={newGoal.category} onValueChange={(value) => setNewGoal({...newGoal, category: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(cat => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="goal-priority">Priority</Label>
                  <Select value={newGoal.priority} onValueChange={(value) => setNewGoal({...newGoal, priority: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {priorities.map(priority => (
                        <SelectItem key={priority} value={priority}>{priority}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="goal-target-date">Target Date</Label>
                <Input
                  id="goal-target-date"
                  type="date"
                  value={newGoal.targetDate}
                  onChange={(e) => setNewGoal({...newGoal, targetDate: e.target.value})}
                />
              </div>
              <Button onClick={addGoal} className="w-full">
                Create Goal
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Goals Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Goals</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{goals.length}</div>
            <p className="text-xs text-muted-foreground">goals set</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedGoals}</div>
            <p className="text-xs text-muted-foreground">goals achieved</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">In Progress</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{inProgressGoals}</div>
            <p className="text-xs text-muted-foreground">active goals</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Progress</CardTitle>
            <Flag className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageProgress}%</div>
            <p className="text-xs text-muted-foreground">overall completion</p>
          </CardContent>
        </Card>
      </div>

      {/* Goals List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Your Goals
          </CardTitle>
        </CardHeader>
        <CardContent>
          {goals.length === 0 ? (
            <div className="p-8 text-center">
              <Target className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No goals yet</h3>
              <p className="text-muted-foreground mb-4">Start setting goals to track your progress and achievements!</p>
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Goal
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {goals.map((goal) => (
                <div key={goal.id} className="p-4 rounded-lg border">
                  {editingGoal === goal.id ? (
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor={`edit-title-${goal.id}`}>Title</Label>
                        <Input
                          id={`edit-title-${goal.id}`}
                          value={editGoal.title}
                          onChange={(e) => setEditGoal({...editGoal, title: e.target.value})}
                        />
                      </div>
                      <div>
                        <Label htmlFor={`edit-description-${goal.id}`}>Description</Label>
                        <Textarea
                          id={`edit-description-${goal.id}`}
                          value={editGoal.description}
                          onChange={(e) => setEditGoal({...editGoal, description: e.target.value})}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor={`edit-category-${goal.id}`}>Category</Label>
                          <Select value={editGoal.category} onValueChange={(value) => setEditGoal({...editGoal, category: value})}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {categories.map(cat => (
                                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor={`edit-priority-${goal.id}`}>Priority</Label>
                          <Select value={editGoal.priority} onValueChange={(value) => setEditGoal({...editGoal, priority: value})}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {priorities.map(priority => (
                                <SelectItem key={priority} value={priority}>{priority}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor={`edit-target-date-${goal.id}`}>Target Date</Label>
                          <Input
                            id={`edit-target-date-${goal.id}`}
                            type="date"
                            value={editGoal.targetDate}
                            onChange={(e) => setEditGoal({...editGoal, targetDate: e.target.value})}
                          />
                        </div>
                        <div>
                          <Label htmlFor={`edit-progress-${goal.id}`}>Progress: {editGoal.progress}%</Label>
                          <Input
                            id={`edit-progress-${goal.id}`}
                            type="range"
                            min="0"
                            max="100"
                            value={editGoal.progress}
                            onChange={(e) => setEditGoal({...editGoal, progress: parseInt(e.target.value)})}
                          />
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => saveGoalEdit(goal.id)}
                        >
                          <Save className="w-4 h-4 mr-2" />
                          Save
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={cancelGoalEdit}
                        >
                          <X className="w-4 h-4 mr-2" />
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-medium">{goal.title}</h3>
                          <Badge className={getStatusColor(goal.status)}>{goal.status}</Badge>
                          <Badge variant="outline" className={getPriorityColor(goal.priority)}>{goal.priority}</Badge>
                          <Badge variant="secondary">{goal.category}</Badge>
                        </div>
                        {goal.description && (
                          <p className="text-sm text-muted-foreground mb-2">{goal.description}</p>
                        )}
                        <div className="flex items-center gap-4 mb-2">
                          <div className="flex items-center gap-2 flex-1">
                            <span className="text-sm text-muted-foreground">Progress:</span>
                            <Progress value={goal.progress} className="flex-1" />
                            <span className="text-sm font-medium">{goal.progress}%</span>
                          </div>
                          {goal.targetDate && (
                            <span className="text-sm text-muted-foreground">Target: {goal.targetDate}</span>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateProgress(goal.id, Math.min(100, goal.progress + 10))}
                            disabled={goal.progress >= 100}
                          >
                            +10% Progress
                          </Button>
                          {goal.progress > 0 && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateProgress(goal.id, Math.max(0, goal.progress - 10))}
                            >
                              -10% Progress
                            </Button>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 ml-4">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => startEditGoal(goal)}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteGoal(goal.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}