import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarTrigger } from "./ui/sidebar";
import { Home, Target, Dumbbell, Heart, Lightbulb, TrendingUp, Smile, BarChart3, LogOut, User } from "lucide-react";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback } from "./ui/avatar";

interface NavigationProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
  onSignOut: () => void;
  userEmail?: string;
}

export function Navigation({ activeSection, onSectionChange, onSignOut, userEmail }: NavigationProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'habits', label: 'Habits', icon: Target },
    { id: 'fitness', label: 'Fitness', icon: Dumbbell },
    { id: 'relationships', label: 'Relationships', icon: Heart },
    { id: 'projects', label: 'Projects', icon: Lightbulb },
    { id: 'goals', label: 'Goals', icon: TrendingUp },
    { id: 'mood', label: 'Mood', icon: Smile },
    { id: 'custom', label: 'Custom Trackers', icon: BarChart3 },
  ];

  return (
    <Sidebar className="bg-sidebar border-r border-sidebar-border">
      <SidebarHeader className="p-6 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Target className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-sidebar-foreground">LifePlan</h2>
            <p className="text-xs text-sidebar-foreground/60">Personal Dashboard</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="px-4 py-4">
        <SidebarMenu className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <SidebarMenuItem key={item.id}>
                <SidebarMenuButton
                  onClick={() => onSectionChange(item.id)}
                  className={`w-full justify-start gap-3 h-11 rounded-lg px-3 py-2 transition-colors ${
                    isActive 
                      ? 'bg-sidebar-primary text-sidebar-primary-foreground font-medium shadow-sm' 
                      : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            );
          })}
        </SidebarMenu>
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-sidebar-border">
        <div className="bg-sidebar-accent p-4 rounded-lg">
          <div className="flex items-center gap-3 mb-3">
            <Avatar className="w-8 h-8 bg-primary">
              <AvatarFallback className="bg-primary text-primary-foreground text-sm">
                {userEmail?.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-sidebar-foreground truncate">
                {userEmail}
              </p>
              <p className="text-xs text-sidebar-foreground/60">Online</p>
            </div>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={onSignOut}
            className="w-full justify-start gap-2 text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground h-9"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}