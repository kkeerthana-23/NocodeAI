import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Heart, Plus, Calendar, Phone, Mail, MessageSquare, Users, Coffee } from "lucide-react";
import { useState, useEffect } from "react";
import { contactsApi } from "../utils/api";
import { toast } from "sonner";

interface Contact {
  id: string;
  name: string;
  relationship: string;
  lastContact: string;
  frequency: string;
  notes: string;
  avatar: string;
  priority: 'High' | 'Medium' | 'Low';
}

export function RelationshipTracker() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);

  useEffect(() => {
    loadContacts();
  }, []);

  const loadContacts = async () => {
    setLoading(true);
    const { data, error } = await contactsApi.getContacts();
    
    if (error) {
      toast.error('Failed to load contacts: ' + error);
    } else if (data) {
      setContacts(data.contacts);
    }
    
    setLoading(false);
  };

  const [newContact, setNewContact] = useState({
    name: '',
    relationship: '',
    frequency: 'Weekly',
    notes: '',
    priority: 'Medium' as 'High' | 'Medium' | 'Low'
  });

  const [activities] = useState([
    { id: '1', type: 'call', contact: 'Sarah Johnson', date: '2024-01-14', note: 'Caught up on weekend plans' },
    { id: '2', type: 'text', contact: 'Mom', date: '2024-01-13', note: 'Sent photos from vacation' },
    { id: '3', type: 'coffee', contact: 'Alex Chen', date: '2024-01-12', note: 'Discussed new project ideas' },
    { id: '4', type: 'video', contact: 'Emma Williams', date: '2024-01-10', note: 'Virtual movie night' }
  ]);

  const relationships = ['Family', 'Best Friend', 'Close Friend', 'Friend', 'Colleague', 'Mentor', 'Acquaintance'];
  const frequencies = ['Daily', 'Weekly', 'Bi-weekly', 'Monthly', 'Quarterly', 'Yearly'];

  const addContact = async () => {
    if (!newContact.name || !newContact.relationship) return;

    const contactData = {
      name: newContact.name,
      relationship: newContact.relationship,
      lastContact: new Date().toISOString().split('T')[0],
      frequency: newContact.frequency,
      notes: newContact.notes,
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=32&h=32&fit=crop&crop=face',
      priority: newContact.priority
    };

    const { data, error } = await contactsApi.createContact(contactData);
    
    if (error) {
      toast.error('Failed to create contact: ' + error);
    } else if (data) {
      setContacts([...contacts, data.contact]);
      setNewContact({ name: '', relationship: '', frequency: 'Weekly', notes: '', priority: 'Medium' });
      setDialogOpen(false);
      toast.success('Contact added successfully!');
    }
  };

  const getOverdueContacts = () => {
    const now = new Date();
    return contacts.filter(contact => {
      const lastContact = new Date(contact.lastContact);
      const daysDiff = Math.floor((now.getTime() - lastContact.getTime()) / (1000 * 60 * 60 * 24));
      
      switch (contact.frequency) {
        case 'Daily': return daysDiff > 1;
        case 'Weekly': return daysDiff > 7;
        case 'Bi-weekly': return daysDiff > 14;
        case 'Monthly': return daysDiff > 30;
        case 'Quarterly': return daysDiff > 90;
        case 'Yearly': return daysDiff > 365;
        default: return false;
      }
    });
  };

  const overdueContacts = getOverdueContacts();
  const highPriorityContacts = contacts.filter(c => c.priority === 'High').length;

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'call': return <Phone className="w-4 h-4" />;
      case 'text': return <MessageSquare className="w-4 h-4" />;
      case 'coffee': return <Coffee className="w-4 h-4" />;
      case 'video': return <Calendar className="w-4 h-4" />;
      default: return <MessageSquare className="w-4 h-4" />;
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-semibold">Relationship Tracker</h1>
            <p className="text-muted-foreground">Loading your contacts...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold">Relationship Tracker</h1>
          <p className="text-muted-foreground">Stay connected with the people who matter</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Contact
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Contact</DialogTitle>
              <DialogDescription>
                Add someone important to track your relationship and stay connected.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="contact-name">Name</Label>
                <Input
                  id="contact-name"
                  value={newContact.name}
                  onChange={(e) => setNewContact({...newContact, name: e.target.value})}
                  placeholder="e.g., John Doe"
                />
              </div>
              <div>
                <Label htmlFor="contact-relationship">Relationship</Label>
                <Select value={newContact.relationship} onValueChange={(value) => setNewContact({...newContact, relationship: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select relationship" />
                  </SelectTrigger>
                  <SelectContent>
                    {relationships.map(rel => (
                      <SelectItem key={rel} value={rel}>{rel}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="contact-frequency">Contact Frequency</Label>
                <Select value={newContact.frequency} onValueChange={(value) => setNewContact({...newContact, frequency: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {frequencies.map(freq => (
                      <SelectItem key={freq} value={freq}>{freq}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="contact-priority">Priority</Label>
                <Select value={newContact.priority} onValueChange={(value: 'High' | 'Medium' | 'Low') => setNewContact({...newContact, priority: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="High">High</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="contact-notes">Notes</Label>
                <Textarea
                  id="contact-notes"
                  value={newContact.notes}
                  onChange={(e) => setNewContact({...newContact, notes: e.target.value})}
                  placeholder="Add any notes about this person"
                />
              </div>
              <Button onClick={addContact} className="w-full">
                Add Contact
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Relationship Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Contacts</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{contacts.length}</div>
            <p className="text-xs text-muted-foreground">active relationships</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">High Priority</CardTitle>
            <Heart className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{highPriorityContacts}</div>
            <p className="text-xs text-muted-foreground">important connections</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overdue</CardTitle>
            <Calendar className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overdueContacts.length}</div>
            <p className="text-xs text-muted-foreground">need to reconnect</p>
          </CardContent>
        </Card>
      </div>

      {/* Overdue Contacts */}
      {overdueContacts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-600">
              <Calendar className="h-5 w-5" />
              Overdue Contacts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {overdueContacts.map((contact) => (
                <div key={contact.id} className="flex items-center justify-between p-3 rounded-lg border border-orange-200">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={contact.avatar} />
                      <AvatarFallback>{contact.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">{contact.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        Last contact: {contact.lastContact} • Expected: {contact.frequency}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => console.log('Call', contact.name)}>
                      <Phone className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => console.log('Text', contact.name)}>
                      <MessageSquare className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {activities.map((activity) => (
              <div key={activity.id} className="flex items-center gap-3 p-3 rounded-lg border">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  {getActivityIcon(activity.type)}
                </div>
                <div className="flex-1">
                  <p className="font-medium">{activity.contact}</p>
                  <p className="text-sm text-muted-foreground">{activity.note}</p>
                </div>
                <div className="text-sm text-muted-foreground">
                  {activity.date}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* All Contacts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            All Contacts
          </CardTitle>
        </CardHeader>
        <CardContent>
          {contacts.length === 0 ? (
            <div className="p-8 text-center">
              <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No contacts yet</h3>
              <p className="text-muted-foreground mb-4">Start building your network by adding your first contact!</p>
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Contact
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {contacts.map((contact) => (
                <div key={contact.id} className="flex items-center justify-between p-3 rounded-lg border">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={contact.avatar} />
                      <AvatarFallback>{contact.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">{contact.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary">{contact.relationship}</Badge>
                        <Badge variant={contact.priority === 'High' ? 'destructive' : contact.priority === 'Medium' ? 'default' : 'outline'}>
                          {contact.priority}
                        </Badge>
                        <span className="text-sm text-muted-foreground">{contact.frequency}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => console.log('Call', contact.name)}>
                      <Phone className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => console.log('Text', contact.name)}>
                      <MessageSquare className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => console.log('Email', contact.name)}>
                      <Mail className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}