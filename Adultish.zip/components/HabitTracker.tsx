import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { CheckCircle, Plus, Target, TrendingUp, Calendar, Flame, Edit, Trash2, Save, X } from "lucide-react";
import { useState, useEffect } from "react";
import { habitsApi } from "../utils/api";
import { toast } from "sonner";

interface Habit {
  id: string;
  name: string;
  description: string;
  frequency: string;
  streak: number;
  completedToday: boolean;
  category: string;
  createdAt: string;
}

export function HabitTracker() {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingHabit, setEditingHabit] = useState<string | null>(null);

  useEffect(() => {
    loadHabits();
  }, []);

  const loadHabits = async () => {
    setLoading(true);
    const { data, error } = await habitsApi.getHabits();
    
    if (error) {
      toast.error('Failed to load habits: ' + error);
    } else if (data) {
      setHabits(data.habits);
    }
    
    setLoading(false);
  };

  const [newHabit, setNewHabit] = useState({
    name: '',
    description: '',
    frequency: 'Daily',
    category: 'Health'
  });

  const [editHabit, setEditHabit] = useState({
    name: '',
    description: '',
    frequency: 'Daily',
    category: 'Health'
  });

  const frequencies = ['Daily', 'Weekly', 'Monthly'];
  const categories = ['Health', 'Productivity', 'Learning', 'Wellness', 'Social', 'Other'];

  const addHabit = async () => {
    if (!newHabit.name.trim()) {
      toast.error('Please enter a habit name');
      return;
    }

    const { data, error } = await habitsApi.createHabit(newHabit);
    
    if (error) {
      toast.error('Failed to create habit: ' + error);
    } else if (data) {
      setHabits([data.habit, ...habits]);
      setNewHabit({ name: '', description: '', frequency: 'Daily', category: 'Health' });
      setDialogOpen(false);
      toast.success('Habit created successfully!');
    }
  };

  const startEditHabit = (habit: Habit) => {
    setEditHabit({
      name: habit.name,
      description: habit.description,
      frequency: habit.frequency,
      category: habit.category
    });
    setEditingHabit(habit.id);
  };

  const saveHabitEdit = async (habitId: string) => {
    if (!editHabit.name.trim()) {
      toast.error('Please enter a habit name');
      return;
    }

    const { data, error } = await habitsApi.updateHabit(habitId, editHabit);

    if (error) {
      toast.error('Failed to update habit: ' + error);
    } else if (data) {
      setHabits(habits.map(h => h.id === habitId ? data.habit : h));
      setEditingHabit(null);
      toast.success('Habit updated successfully!');
    }
  };

  const cancelHabitEdit = () => {
    setEditingHabit(null);
    setEditHabit({ name: '', description: '', frequency: 'Daily', category: 'Health' });
  };

  const deleteHabit = async (habitId: string) => {
    if (!confirm('Are you sure you want to delete this habit?')) return;

    const { error } = await habitsApi.deleteHabit(habitId);
    
    if (error) {
      toast.error('Failed to delete habit: ' + error);
    } else {
      setHabits(habits.filter(h => h.id !== habitId));
      toast.success('Habit deleted successfully!');
    }
  };

  const toggleHabitCompletion = async (habitId: string) => {
    const habit = habits.find(h => h.id === habitId);
    if (!habit) return;

    const updates = {
      completedToday: !habit.completedToday,
      streak: !habit.completedToday ? habit.streak + 1 : Math.max(0, habit.streak - 1)
    };

    const { data, error } = await habitsApi.updateHabit(habitId, updates);

    if (error) {
      toast.error('Failed to update habit: ' + error);
    } else if (data) {
      setHabits(habits.map(h => h.id === habitId ? data.habit : h));
      toast.success(!habit.completedToday ? 'Great job! Habit completed!' : 'Habit marked as incomplete');
    }
  };

  const completedHabits = habits.filter(h => h.completedToday).length;
  const totalStreak = habits.reduce((sum, h) => sum + h.streak, 0);
  const longestStreak = Math.max(...habits.map(h => h.streak), 0);
  const completionRate = habits.length > 0 ? Math.round((completedHabits / habits.length) * 100) : 0;

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-semibold">Habit Tracker</h1>
            <p className="text-muted-foreground">Loading your habits...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold">Habit Tracker</h1>
          <p className="text-muted-foreground">Build consistent habits and track your progress</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Habit
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Habit</DialogTitle>
              <DialogDescription>
                Add a new habit to track and build consistency in your daily routine.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="habit-name">Habit Name</Label>
                <Input
                  id="habit-name"
                  value={newHabit.name}
                  onChange={(e) => setNewHabit({...newHabit, name: e.target.value})}
                  placeholder="e.g., Drink 8 glasses of water"
                />
              </div>
              <div>
                <Label htmlFor="habit-description">Description (optional)</Label>
                <Textarea
                  id="habit-description"
                  value={newHabit.description}
                  onChange={(e) => setNewHabit({...newHabit, description: e.target.value})}
                  placeholder="Why is this habit important to you?"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="habit-frequency">Frequency</Label>
                  <Select value={newHabit.frequency} onValueChange={(value) => setNewHabit({...newHabit, frequency: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {frequencies.map(freq => (
                        <SelectItem key={freq} value={freq}>{freq}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="habit-category">Category</Label>
                  <Select value={newHabit.category} onValueChange={(value) => setNewHabit({...newHabit, category: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(cat => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button onClick={addHabit} className="w-full">
                Create Habit
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Habit Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Progress</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedHabits}/{habits.length}</div>
            <div className="flex items-center gap-2 mt-2">
              <Progress value={completionRate} className="flex-1" />
              <span className="text-sm text-muted-foreground">{completionRate}%</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Streaks</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalStreak}</div>
            <p className="text-xs text-muted-foreground">days across all habits</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Longest Streak</CardTitle>
            <Flame className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{longestStreak}</div>
            <p className="text-xs text-muted-foreground">days in a row</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Habits</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{habits.length}</div>
            <p className="text-xs text-muted-foreground">being tracked</p>
          </CardContent>
        </Card>
      </div>

      {/* Habits List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Your Habits
          </CardTitle>
        </CardHeader>
        <CardContent>
          {habits.length === 0 ? (
            <div className="p-8 text-center">
              <Target className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No habits yet</h3>
              <p className="text-muted-foreground mb-4">Start building better habits today!</p>
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Habit
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {habits.map((habit) => (
                <div key={habit.id} className="flex items-center justify-between p-4 rounded-lg border">
                  {editingHabit === habit.id ? (
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4 mr-4">
                      <div>
                        <Label htmlFor={`edit-name-${habit.id}`}>Name</Label>
                        <Input
                          id={`edit-name-${habit.id}`}
                          value={editHabit.name}
                          onChange={(e) => setEditHabit({...editHabit, name: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor={`edit-description-${habit.id}`}>Description</Label>
                        <Input
                          id={`edit-description-${habit.id}`}
                          value={editHabit.description}
                          onChange={(e) => setEditHabit({...editHabit, description: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor={`edit-frequency-${habit.id}`}>Frequency</Label>
                        <Select value={editHabit.frequency} onValueChange={(value) => setEditHabit({...editHabit, frequency: value})}>
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {frequencies.map(freq => (
                              <SelectItem key={freq} value={freq}>{freq}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor={`edit-category-${habit.id}`}>Category</Label>
                        <Select value={editHabit.category} onValueChange={(value) => setEditHabit({...editHabit, category: value})}>
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map(cat => (
                              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-4 flex-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleHabitCompletion(habit.id)}
                        className={`w-8 h-8 rounded-full p-0 ${
                          habit.completedToday ? 'bg-green-100 text-green-600' : 'border-2 border-muted'
                        }`}
                      >
                        {habit.completedToday && <CheckCircle className="w-4 h-4" />}
                      </Button>
                      <div className="flex-1">
                        <h3 className={`font-medium ${habit.completedToday ? 'line-through text-muted-foreground' : ''}`}>
                          {habit.name}
                        </h3>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="secondary">{habit.category}</Badge>
                          <Badge variant="outline">{habit.frequency}</Badge>
                          <span className="text-sm text-muted-foreground flex items-center gap-1">
                            <Flame className="w-3 h-3" />
                            {habit.streak} day streak
                          </span>
                        </div>
                        {habit.description && (
                          <p className="text-sm text-muted-foreground mt-1">{habit.description}</p>
                        )}
                      </div>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    {editingHabit === habit.id ? (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => saveHabitEdit(habit.id)}
                          className="text-green-600 hover:text-green-700"
                        >
                          <Save className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={cancelHabitEdit}
                          className="text-gray-600 hover:text-gray-700"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => startEditHabit(habit)}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteHabit(habit.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Habit Categories */}
      <Card>
        <CardHeader>
          <CardTitle>Habits by Category</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {categories.map(category => {
              const count = habits.filter(h => h.category === category).length;
              const completed = habits.filter(h => h.category === category && h.completedToday).length;
              const percentage = count > 0 ? (completed / count) * 100 : 0;
              
              return (
                <div key={category} className="text-center p-4 bg-secondary/50 rounded-lg">
                  <div className="text-lg font-bold text-primary">{completed}/{count}</div>
                  <div className="text-sm text-muted-foreground">{category}</div>
                  <div className="w-full bg-secondary rounded-full h-2 mt-2">
                    <div 
                      className="bg-primary h-2 rounded-full transition-all duration-300"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}