import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Dumbbell, Plus, Calendar, TrendingUp, Clock, Target, Activity, Edit, Trash2, Save, X } from "lucide-react";
import { useState, useEffect } from "react";
import { workoutsApi } from "../utils/api";
import { toast } from "sonner";

interface Workout {
  id: string;
  name: string;
  type: string;
  duration: number;
  date: string;
  exercises: Exercise[];
}

interface Exercise {
  name: string;
  sets: number;
  reps: number;
  weight?: number;
}

export function FitnessTracker() {
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingWorkout, setEditingWorkout] = useState<string | null>(null);

  useEffect(() => {
    loadWorkouts();
  }, []);

  const loadWorkouts = async () => {
    setLoading(true);
    const { data, error } = await workoutsApi.getWorkouts();
    
    if (error) {
      toast.error('Failed to load workouts: ' + error);
    } else if (data) {
      setWorkouts(data.workouts);
    }
    
    setLoading(false);
  };

  const [newWorkout, setNewWorkout] = useState({
    name: '',
    type: 'Strength',
    duration: 0,
    exercises: []
  });

  const [editWorkout, setEditWorkout] = useState({
    name: '',
    type: 'Strength',
    duration: 0,
    exercises: []
  });

  const [healthMetrics] = useState({
    weight: 165,
    bodyFat: 15,
    weeklyGoal: 4,
    completedWorkouts: 3
  });

  const workoutTypes = ['Strength', 'Cardio', 'Flexibility', 'Sports', 'Other'];
  const thisWeekWorkouts = workouts.filter(w => {
    const workoutDate = new Date(w.date);
    const today = new Date();
    const weekStart = new Date(today.setDate(today.getDate() - today.getDay()));
    return workoutDate >= weekStart;
  });

  const totalMinutes = thisWeekWorkouts.reduce((sum, w) => sum + w.duration, 0);
  const goalProgress = Math.round((thisWeekWorkouts.length / healthMetrics.weeklyGoal) * 100);

  const addWorkout = async () => {
    if (!newWorkout.name || newWorkout.duration <= 0) {
      toast.error('Please fill in all required fields');
      return;
    }

    const workoutData = {
      name: newWorkout.name,
      type: newWorkout.type,
      duration: newWorkout.duration,
      exercises: []
    };

    const { data, error } = await workoutsApi.createWorkout(workoutData);
    
    if (error) {
      toast.error('Failed to create workout: ' + error);
    } else if (data) {
      setWorkouts([data.workout, ...workouts]);
      setNewWorkout({ name: '', type: 'Strength', duration: 0, exercises: [] });
      setDialogOpen(false);
      toast.success('Workout logged successfully!');
    }
  };

  const startEditWorkout = (workout: Workout) => {
    setEditWorkout({
      name: workout.name,
      type: workout.type,
      duration: workout.duration,
      exercises: workout.exercises || []
    });
    setEditingWorkout(workout.id);
  };

  const saveWorkoutEdit = async (workoutId: string) => {
    if (!editWorkout.name || editWorkout.duration <= 0) {
      toast.error('Please fill in all required fields');
      return;
    }

    const { data, error } = await workoutsApi.updateWorkout(workoutId, {
      name: editWorkout.name,
      type: editWorkout.type,
      duration: editWorkout.duration,
      exercises: editWorkout.exercises
    });

    if (error) {
      toast.error('Failed to update workout: ' + error);
    } else if (data) {
      setWorkouts(workouts.map(w => w.id === workoutId ? data.workout : w));
      setEditingWorkout(null);
      toast.success('Workout updated successfully!');
    }
  };

  const cancelWorkoutEdit = () => {
    setEditingWorkout(null);
    setEditWorkout({ name: '', type: 'Strength', duration: 0, exercises: [] });
  };

  const deleteWorkout = async (workoutId: string) => {
    if (!confirm('Are you sure you want to delete this workout?')) return;

    const { error } = await workoutsApi.deleteWorkout(workoutId);
    
    if (error) {
      toast.error('Failed to delete workout: ' + error);
    } else {
      setWorkouts(workouts.filter(w => w.id !== workoutId));
      toast.success('Workout deleted successfully!');
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-semibold">Fitness Tracker</h1>
            <p className="text-muted-foreground">Loading your workouts...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold">Fitness Tracker</h1>
          <p className="text-muted-foreground">Track your workouts and health progress</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Log Workout
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Log New Workout</DialogTitle>
              <DialogDescription>
                Record a new workout session with details about duration and type.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="workout-name">Workout Name</Label>
                <Input
                  id="workout-name"
                  value={newWorkout.name}
                  onChange={(e) => setNewWorkout({...newWorkout, name: e.target.value})}
                  placeholder="e.g., Morning Run"
                />
              </div>
              <div>
                <Label htmlFor="workout-type">Type</Label>
                <Select value={newWorkout.type} onValueChange={(value) => setNewWorkout({...newWorkout, type: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {workoutTypes.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="workout-duration">Duration (minutes)</Label>
                <Input
                  id="workout-duration"
                  type="number"
                  value={newWorkout.duration}
                  onChange={(e) => setNewWorkout({...newWorkout, duration: parseInt(e.target.value) || 0})}
                  placeholder="45"
                />
              </div>
              <Button onClick={addWorkout} className="w-full">
                Log Workout
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Fitness Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">This Week</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{thisWeekWorkouts.length}/{healthMetrics.weeklyGoal}</div>
            <div className="flex items-center gap-2 mt-2">
              <Progress value={goalProgress} className="flex-1" />
              <span className="text-sm text-muted-foreground">{goalProgress}%</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalMinutes}m</div>
            <p className="text-xs text-muted-foreground">this week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Weight</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{healthMetrics.weight}lbs</div>
            <p className="text-xs text-green-600">-2 lbs this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Body Fat</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{healthMetrics.bodyFat}%</div>
            <p className="text-xs text-green-600">-1% this month</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Workouts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Recent Workouts
          </CardTitle>
        </CardHeader>
        <CardContent>
          {workouts.length === 0 ? (
            <div className="p-8 text-center">
              <Dumbbell className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No workouts yet</h3>
              <p className="text-muted-foreground mb-4">Start your fitness journey by logging your first workout!</p>
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Log Your First Workout
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {workouts.slice(0, 5).map((workout) => (
                <div key={workout.id} className="flex items-center justify-between p-4 rounded-lg border">
                  {editingWorkout === workout.id ? (
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4 mr-4">
                      <div>
                        <Label htmlFor={`edit-name-${workout.id}`}>Name</Label>
                        <Input
                          id={`edit-name-${workout.id}`}
                          value={editWorkout.name}
                          onChange={(e) => setEditWorkout({...editWorkout, name: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor={`edit-type-${workout.id}`}>Type</Label>
                        <Select value={editWorkout.type} onValueChange={(value) => setEditWorkout({...editWorkout, type: value})}>
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {workoutTypes.map(type => (
                              <SelectItem key={type} value={type}>{type}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor={`edit-duration-${workout.id}`}>Duration (min)</Label>
                        <Input
                          id={`edit-duration-${workout.id}`}
                          type="number"
                          value={editWorkout.duration}
                          onChange={(e) => setEditWorkout({...editWorkout, duration: parseInt(e.target.value) || 0})}
                          className="mt-1"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-4 flex-1">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Dumbbell className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium">{workout.name}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="secondary">{workout.type}</Badge>
                          <span className="text-sm text-muted-foreground">{workout.duration} min</span>
                          <span className="text-sm text-muted-foreground">{workout.date}</span>
                        </div>
                      </div>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    {editingWorkout === workout.id ? (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => saveWorkoutEdit(workout.id)}
                          className="text-green-600 hover:text-green-700"
                        >
                          <Save className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={cancelWorkoutEdit}
                          className="text-gray-600 hover:text-gray-700"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => startEditWorkout(workout)}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteWorkout(workout.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Workout Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Workout Types Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {workoutTypes.map(type => {
              const count = workouts.filter(w => w.type === type).length;
              const percentage = workouts.length > 0 ? (count / workouts.length) * 100 : 0;
              return (
                <div key={type} className="text-center">
                  <div className="text-2xl font-bold text-primary">{count}</div>
                  <div className="text-sm text-muted-foreground">{type}</div>
                  <div className="w-full bg-secondary rounded-full h-2 mt-2">
                    <div 
                      className="bg-primary h-2 rounded-full transition-all duration-300"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}