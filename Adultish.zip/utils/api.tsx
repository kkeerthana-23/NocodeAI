import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from './supabase/info';

const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-5d85cfd7`;

interface ApiResponse<T> {
  data?: T;
  error?: string;
}

// Auth utilities
export const auth = {
  async signUp(email: string, password: string, name: string): Promise<ApiResponse<any>> {
    try {
      const response = await fetch(`${API_BASE}/signup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({ email, password, name }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        return { error: data.error || 'Signup failed' };
      }

      return { data };
    } catch (error) {
      console.error('Signup error:', error);
      return { error: 'Network error during signup' };
    }
  },

  async signIn(email: string, password: string): Promise<ApiResponse<any>> {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        return { error: error.message };
      }

      return { data };
    } catch (error) {
      console.error('Sign in error:', error);
      return { error: 'Network error during sign in' };
    }
  },

  async signOut(): Promise<void> {
    await supabase.auth.signOut();
  },

  async getSession() {
    const { data: { session }, error } = await supabase.auth.getSession();
    return { session, error };
  },

  onAuthStateChange(callback: (session: any) => void) {
    return supabase.auth.onAuthStateChange((event, session) => {
      callback(session);
    });
  }
};

// Generic API request function
async function apiRequest<T>(
  endpoint: string, 
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    const accessToken = session?.access_token;

    if (!accessToken) {
      return { error: 'Authentication required' };
    }

    const response = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`,
        ...options.headers,
      },
    });

    const data = await response.json();

    if (!response.ok) {
      console.error(`API Error ${response.status}:`, data);
      return { error: data.error || `Request failed with status ${response.status}` };
    }

    return { data };
  } catch (error) {
    console.error('API request error:', error);
    return { error: 'Network error' };
  }
}

// Habits API
export const habitsApi = {
  async getHabits() {
    return apiRequest<{ habits: any[] }>('/habits');
  },

  async createHabit(habit: any) {
    return apiRequest<{ habit: any }>('/habits', {
      method: 'POST',
      body: JSON.stringify(habit),
    });
  },

  async updateHabit(id: string, updates: any) {
    return apiRequest<{ habit: any }>(`/habits/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async deleteHabit(id: string) {
    return apiRequest<{}>(`/habits/${id}`, {
      method: 'DELETE',
    });
  }
};

// Workouts API
export const workoutsApi = {
  async getWorkouts() {
    return apiRequest<{ workouts: any[] }>('/workouts');
  },

  async createWorkout(workout: any) {
    return apiRequest<{ workout: any }>('/workouts', {
      method: 'POST',
      body: JSON.stringify(workout),
    });
  },

  async updateWorkout(id: string, updates: any) {
    return apiRequest<{ workout: any }>(`/workouts/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async deleteWorkout(id: string) {
    return apiRequest<{}>(`/workouts/${id}`, {
      method: 'DELETE',
    });
  }
};

// Contacts API
export const contactsApi = {
  async getContacts() {
    return apiRequest<{ contacts: any[] }>('/contacts');
  },

  async createContact(contact: any) {
    return apiRequest<{ contact: any }>('/contacts', {
      method: 'POST',
      body: JSON.stringify(contact),
    });
  },

  async updateContact(id: string, updates: any) {
    return apiRequest<{ contact: any }>(`/contacts/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async deleteContact(id: string) {
    return apiRequest<{}>(`/contacts/${id}`, {
      method: 'DELETE',
    });
  }
};

// Projects API
export const projectsApi = {
  async getProjects() {
    return apiRequest<{ projects: any[] }>('/projects');
  },

  async createProject(project: any) {
    return apiRequest<{ project: any }>('/projects', {
      method: 'POST',
      body: JSON.stringify(project),
    });
  },

  async updateProject(id: string, updates: any) {
    return apiRequest<{ project: any }>(`/projects/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async deleteProject(id: string) {
    return apiRequest<{}>(`/projects/${id}`, {
      method: 'DELETE',
    });
  }
};

// Goals API
export const goalsApi = {
  async getGoals() {
    return apiRequest<{ goals: any[] }>('/goals');
  },

  async createGoal(goal: any) {
    return apiRequest<{ goal: any }>('/goals', {
      method: 'POST',
      body: JSON.stringify(goal),
    });
  },

  async updateGoal(id: string, updates: any) {
    return apiRequest<{ goal: any }>(`/goals/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async deleteGoal(id: string) {
    return apiRequest<{}>(`/goals/${id}`, {
      method: 'DELETE',
    });
  }
};

// Profile API
export const profileApi = {
  async getProfile() {
    return apiRequest<{ profile: any }>('/profile');
  }
};

// Mood API
export const moodApi = {
  async getMoodEntries() {
    return apiRequest<{ moods: any[] }>('/moods');
  },

  async createMoodEntry(mood: any) {
    return apiRequest<{ mood: any }>('/moods', {
      method: 'POST',
      body: JSON.stringify(mood),
    });
  },

  async updateMoodEntry(id: string, updates: any) {
    return apiRequest<{ mood: any }>(`/moods/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async deleteMoodEntry(id: string) {
    return apiRequest<{}>(`/moods/${id}`, {
      method: 'DELETE',
    });
  }
};

// Custom Trackers API
export const customTrackersApi = {
  async getTrackers() {
    return apiRequest<{ trackers: any[] }>('/custom-trackers');
  },

  async createTracker(tracker: any) {
    return apiRequest<{ tracker: any }>('/custom-trackers', {
      method: 'POST',
      body: JSON.stringify(tracker),
    });
  },

  async updateTracker(id: string, updates: any) {
    return apiRequest<{ tracker: any }>(`/custom-trackers/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async deleteTracker(id: string) {
    return apiRequest<{}>(`/custom-trackers/${id}`, {
      method: 'DELETE',
    });
  },

  async addEntry(trackerId: string, entry: any) {
    return apiRequest<{ entry: any }>(`/custom-trackers/${trackerId}/entries`, {
      method: 'POST',
      body: JSON.stringify(entry),
    });
  },

  async updateEntry(trackerId: string, entryId: string, updates: any) {
    return apiRequest<{ entry: any }>(`/custom-trackers/${trackerId}/entries/${entryId}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async deleteEntry(trackerId: string, entryId: string) {
    return apiRequest<{}>(`/custom-trackers/${trackerId}/entries/${entryId}`, {
      method: 'DELETE',
    });
  }
};