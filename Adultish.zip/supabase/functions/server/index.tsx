import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'jsr:@supabase/supabase-js'
import * as kv from './kv_store.tsx'

const app = new Hono()

// Enable CORS and logging
app.use('*', cors())
app.use('*', logger(console.log))

// Create Supabase client for server operations
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
)

// Middleware for authentication
const requireAuth = async (c: any, next: any) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  if (!accessToken) {
    return c.json({ error: 'Authorization header required' }, 401);
  }

  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  if (error || !user) {
    console.log('Authorization error:', error);
    return c.json({ error: 'Invalid or expired token' }, 401);
  }

  c.set('userId', user.id);
  await next();
};

// User registration
app.post('/make-server-5d85cfd7/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    if (!email || !password || !name) {
      return c.json({ error: 'Email, password, and name are required' }, 400);
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }

    // Initialize user data
    const userId = data.user.id;
    await kv.set(`user_profile_${userId}`, {
      id: userId,
      name,
      email,
      createdAt: new Date().toISOString()
    });

    return c.json({ 
      message: 'User created successfully',
      user: data.user 
    });
  } catch (error) {
    console.log('Signup error during user creation:', error);
    return c.json({ error: 'Failed to create user' }, 500);
  }
});

// Habits management
app.get('/make-server-5d85cfd7/habits', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const habits = await kv.get(`habits_${userId}`) || [];
    return c.json({ habits });
  } catch (error) {
    console.log('Error fetching habits:', error);
    return c.json({ error: 'Failed to fetch habits' }, 500);
  }
});

app.post('/make-server-5d85cfd7/habits', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const habit = await c.req.json();
    
    const habits = await kv.get(`habits_${userId}`) || [];
    const newHabit = {
      ...habit,
      id: Date.now().toString(),
      userId,
      createdAt: new Date().toISOString()
    };
    
    habits.push(newHabit);
    await kv.set(`habits_${userId}`, habits);
    
    return c.json({ habit: newHabit });
  } catch (error) {
    console.log('Error creating habit:', error);
    return c.json({ error: 'Failed to create habit' }, 500);
  }
});

app.put('/make-server-5d85cfd7/habits/:id', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const habitId = c.req.param('id');
    const updates = await c.req.json();
    
    const habits = await kv.get(`habits_${userId}`) || [];
    const habitIndex = habits.findIndex((h: any) => h.id === habitId);
    
    if (habitIndex === -1) {
      return c.json({ error: 'Habit not found' }, 404);
    }
    
    habits[habitIndex] = { ...habits[habitIndex], ...updates };
    await kv.set(`habits_${userId}`, habits);
    
    return c.json({ habit: habits[habitIndex] });
  } catch (error) {
    console.log('Error updating habit:', error);
    return c.json({ error: 'Failed to update habit' }, 500);
  }
});

// Fitness data management
app.get('/make-server-5d85cfd7/workouts', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const workouts = await kv.get(`workouts_${userId}`) || [];
    return c.json({ workouts });
  } catch (error) {
    console.log('Error fetching workouts:', error);
    return c.json({ error: 'Failed to fetch workouts' }, 500);
  }
});

app.post('/make-server-5d85cfd7/workouts', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const workout = await c.req.json();
    
    const workouts = await kv.get(`workouts_${userId}`) || [];
    const newWorkout = {
      ...workout,
      id: Date.now().toString(),
      userId,
      date: new Date().toISOString().split('T')[0]
    };
    
    workouts.unshift(newWorkout);
    await kv.set(`workouts_${userId}`, workouts);
    
    return c.json({ workout: newWorkout });
  } catch (error) {
    console.log('Error creating workout:', error);
    return c.json({ error: 'Failed to create workout' }, 500);
  }
});

// Relationships management
app.get('/make-server-5d85cfd7/contacts', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const contacts = await kv.get(`contacts_${userId}`) || [];
    return c.json({ contacts });
  } catch (error) {
    console.log('Error fetching contacts:', error);
    return c.json({ error: 'Failed to fetch contacts' }, 500);
  }
});

app.post('/make-server-5d85cfd7/contacts', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const contact = await c.req.json();
    
    const contacts = await kv.get(`contacts_${userId}`) || [];
    const newContact = {
      ...contact,
      id: Date.now().toString(),
      userId,
      createdAt: new Date().toISOString()
    };
    
    contacts.push(newContact);
    await kv.set(`contacts_${userId}`, contacts);
    
    return c.json({ contact: newContact });
  } catch (error) {
    console.log('Error creating contact:', error);
    return c.json({ error: 'Failed to create contact' }, 500);
  }
});

// Projects management
app.get('/make-server-5d85cfd7/projects', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const projects = await kv.get(`projects_${userId}`) || [];
    return c.json({ projects });
  } catch (error) {
    console.log('Error fetching projects:', error);
    return c.json({ error: 'Failed to fetch projects' }, 500);
  }
});

app.post('/make-server-5d85cfd7/projects', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const project = await c.req.json();
    
    const projects = await kv.get(`projects_${userId}`) || [];
    const newProject = {
      ...project,
      id: Date.now().toString(),
      userId,
      createdAt: new Date().toISOString()
    };
    
    projects.push(newProject);
    await kv.set(`projects_${userId}`, projects);
    
    return c.json({ project: newProject });
  } catch (error) {
    console.log('Error creating project:', error);
    return c.json({ error: 'Failed to create project' }, 500);
  }
});

app.put('/make-server-5d85cfd7/projects/:id', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const projectId = c.req.param('id');
    const updates = await c.req.json();
    
    const projects = await kv.get(`projects_${userId}`) || [];
    const projectIndex = projects.findIndex((p: any) => p.id === projectId);
    
    if (projectIndex === -1) {
      return c.json({ error: 'Project not found' }, 404);
    }
    
    projects[projectIndex] = { ...projects[projectIndex], ...updates };
    await kv.set(`projects_${userId}`, projects);
    
    return c.json({ project: projects[projectIndex] });
  } catch (error) {
    console.log('Error updating project:', error);
    return c.json({ error: 'Failed to update project' }, 500);
  }
});

// Goals management
app.get('/make-server-5d85cfd7/goals', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const goals = await kv.get(`goals_${userId}`) || [];
    return c.json({ goals });
  } catch (error) {
    console.log('Error fetching goals:', error);
    return c.json({ error: 'Failed to fetch goals' }, 500);
  }
});

app.post('/make-server-5d85cfd7/goals', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const goal = await c.req.json();
    
    const goals = await kv.get(`goals_${userId}`) || [];
    const newGoal = {
      ...goal,
      id: Date.now().toString(),
      userId,
      createdAt: new Date().toISOString()
    };
    
    goals.push(newGoal);
    await kv.set(`goals_${userId}`, goals);
    
    return c.json({ goal: newGoal });
  } catch (error) {
    console.log('Error creating goal:', error);
    return c.json({ error: 'Failed to create goal' }, 500);
  }
});

app.put('/make-server-5d85cfd7/goals/:id', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const goalId = c.req.param('id');
    const updates = await c.req.json();
    
    const goals = await kv.get(`goals_${userId}`) || [];
    const goalIndex = goals.findIndex((g: any) => g.id === goalId);
    
    if (goalIndex === -1) {
      return c.json({ error: 'Goal not found' }, 404);
    }
    
    goals[goalIndex] = { ...goals[goalIndex], ...updates };
    await kv.set(`goals_${userId}`, goals);
    
    return c.json({ goal: goals[goalIndex] });
  } catch (error) {
    console.log('Error updating goal:', error);
    return c.json({ error: 'Failed to update goal' }, 500);
  }
});

// Mood tracking
app.get('/make-server-5d85cfd7/moods', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const moods = await kv.get(`moods_${userId}`) || [];
    return c.json({ moods });
  } catch (error) {
    console.log('Error fetching moods:', error);
    return c.json({ error: 'Failed to fetch moods' }, 500);
  }
});

app.post('/make-server-5d85cfd7/moods', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const mood = await c.req.json();
    
    const moods = await kv.get(`moods_${userId}`) || [];
    const newMood = {
      ...mood,
      id: Date.now().toString(),
      userId,
      createdAt: new Date().toISOString()
    };
    
    moods.unshift(newMood);
    await kv.set(`moods_${userId}`, moods);
    
    return c.json({ mood: newMood });
  } catch (error) {
    console.log('Error creating mood entry:', error);
    return c.json({ error: 'Failed to create mood entry' }, 500);
  }
});

app.put('/make-server-5d85cfd7/moods/:id', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const moodId = c.req.param('id');
    const updates = await c.req.json();
    
    const moods = await kv.get(`moods_${userId}`) || [];
    const moodIndex = moods.findIndex((m: any) => m.id === moodId);
    
    if (moodIndex === -1) {
      return c.json({ error: 'Mood entry not found' }, 404);
    }
    
    moods[moodIndex] = { ...moods[moodIndex], ...updates };
    await kv.set(`moods_${userId}`, moods);
    
    return c.json({ mood: moods[moodIndex] });
  } catch (error) {
    console.log('Error updating mood entry:', error);
    return c.json({ error: 'Failed to update mood entry' }, 500);
  }
});

// Custom trackers
app.get('/make-server-5d85cfd7/custom-trackers', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const trackers = await kv.get(`custom_trackers_${userId}`) || [];
    return c.json({ trackers });
  } catch (error) {
    console.log('Error fetching custom trackers:', error);
    return c.json({ error: 'Failed to fetch custom trackers' }, 500);
  }
});

app.post('/make-server-5d85cfd7/custom-trackers', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const tracker = await c.req.json();
    
    const trackers = await kv.get(`custom_trackers_${userId}`) || [];
    const newTracker = {
      ...tracker,
      id: Date.now().toString(),
      userId,
      createdAt: new Date().toISOString(),
      entries: []
    };
    
    trackers.push(newTracker);
    await kv.set(`custom_trackers_${userId}`, trackers);
    
    return c.json({ tracker: newTracker });
  } catch (error) {
    console.log('Error creating custom tracker:', error);
    return c.json({ error: 'Failed to create custom tracker' }, 500);
  }
});

app.put('/make-server-5d85cfd7/custom-trackers/:id', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const trackerId = c.req.param('id');
    const updates = await c.req.json();
    
    const trackers = await kv.get(`custom_trackers_${userId}`) || [];
    const trackerIndex = trackers.findIndex((t: any) => t.id === trackerId);
    
    if (trackerIndex === -1) {
      return c.json({ error: 'Custom tracker not found' }, 404);
    }
    
    trackers[trackerIndex] = { ...trackers[trackerIndex], ...updates };
    await kv.set(`custom_trackers_${userId}`, trackers);
    
    return c.json({ tracker: trackers[trackerIndex] });
  } catch (error) {
    console.log('Error updating custom tracker:', error);
    return c.json({ error: 'Failed to update custom tracker' }, 500);
  }
});

app.delete('/make-server-5d85cfd7/custom-trackers/:id', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const trackerId = c.req.param('id');
    
    const trackers = await kv.get(`custom_trackers_${userId}`) || [];
    const filteredTrackers = trackers.filter((t: any) => t.id !== trackerId);
    
    if (filteredTrackers.length === trackers.length) {
      return c.json({ error: 'Custom tracker not found' }, 404);
    }
    
    await kv.set(`custom_trackers_${userId}`, filteredTrackers);
    
    return c.json({ message: 'Custom tracker deleted successfully' });
  } catch (error) {
    console.log('Error deleting custom tracker:', error);
    return c.json({ error: 'Failed to delete custom tracker' }, 500);
  }
});

app.post('/make-server-5d85cfd7/custom-trackers/:id/entries', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const trackerId = c.req.param('id');
    const entry = await c.req.json();
    
    const trackers = await kv.get(`custom_trackers_${userId}`) || [];
    const trackerIndex = trackers.findIndex((t: any) => t.id === trackerId);
    
    if (trackerIndex === -1) {
      return c.json({ error: 'Custom tracker not found' }, 404);
    }
    
    const newEntry = {
      ...entry,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    
    if (!trackers[trackerIndex].entries) {
      trackers[trackerIndex].entries = [];
    }
    
    trackers[trackerIndex].entries.unshift(newEntry);
    await kv.set(`custom_trackers_${userId}`, trackers);
    
    return c.json({ entry: newEntry });
  } catch (error) {
    console.log('Error adding tracker entry:', error);
    return c.json({ error: 'Failed to add tracker entry' }, 500);
  }
});

// User profile
app.get('/make-server-5d85cfd7/profile', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const profile = await kv.get(`user_profile_${userId}`);
    return c.json({ profile });
  } catch (error) {
    console.log('Error fetching profile:', error);
    return c.json({ error: 'Failed to fetch profile' }, 500);
  }
});

// Health check
app.get('/make-server-5d85cfd7/health', (c) => {
  return c.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

Deno.serve(app.fetch)